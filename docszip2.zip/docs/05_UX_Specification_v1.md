# UX Specification

**Document ID**\
DOC-005

**Project**\
Werken aan Werk

**Versie**\
1.0

**Status**\
Design Ready

## UX001 -- Home

### Doel

De jongere direct overzicht geven en zonder zoeken verder helpen.

### Gewenste beleving

*"Fijn dat je er bent. Ik zie meteen wat nu belangrijk is."*

### Inhoud

-   Dynamische welkomsttekst
-   Volgende stap
-   Eerstvolgende afspraak
-   Bericht begeleider
-   Maximaal vier dynamische snelkoppelingen

### Interacties

-   Traject openen
-   Afspraak openen
-   Bericht openen
-   Mijn omgeving openen

### Onderste navigatie

-   Home
-   Traject
-   Berichten
-   Mijn omgeving

### Succescriteria

-   Volgende stap direct zichtbaar
-   Niet hoeven zoeken
-   Rustige uitstraling

## UX002 -- Traject

Doel: inzicht geven in de route met actuele, afgeronde en komende
stappen.

## UX003 -- Trajectstap

Doel: ondersteunen bij de actuele stap met uitleg, opdrachten, reflectie
en downloads.

## UX004 -- Berichten

Doel: veilige communicatie tussen jongere en begeleider.

## UX005 -- Mijn omgeving

Doel: alle persoonlijke trajectinformatie op één centrale plek.

## UX006 -- Dashboard begeleider

Doel: overzicht bieden voor begeleiding.

## Ontwerpprincipes

-   Structuur geeft ruimte.
-   Positieve taal.
-   De app ondersteunt de begeleiding; de regie over de begeleiding
    blijft bij de begeleider.
-   Mobile first.

## Reviewstatus

-   Lars van Borssum Waalkes: Gereed voor review
-   Brita: Gereed voor review

## Wijzigingshistorie

-   v1.0: UX Specification volledig uitgewerkt en afgestemd.

## GitHub

Bestandsnaam: docs/05_UX_Specification.md

Commit message: Finalize UX Specification v1.0

Commit description: Complete UX Specification with expanded UX sections
and aligned terminology.
